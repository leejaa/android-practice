package com.example.qrcodereader

interface OnDetectListener {
    fun onDetect(msg : String) // ❶
}
